package com.example.sireesharmi.courses;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button android;
    Button web;
    Button hadoop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        android=(Button)findViewById(R.id.androidapp);
        web=(Button)findViewById(R.id.web);
        hadoop=(Button)findViewById(R.id.hadoop);

        android.setOnClickListener(this);
        web.setOnClickListener(this);
        hadoop.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id=v.getId();
        switch (id){
            case R.id.androidapp:
                Intent intent=new Intent(MainActivity.this,SecondActivity.class);
                intent.putExtra("Mentor:","Murthy");
                startActivity(intent);
                break;
            case R.id.web:
                Intent wintent=new Intent(MainActivity.this,SecondActivity.class);
                wintent.putExtra("Mentor:","Vamsi");
                startActivity(wintent);
                break;
            case R.id.hadoop:
                Intent hintent=new Intent(MainActivity.this,SecondActivity.class);
                hintent.putExtra("Mentor:","Surya");
                startActivity(hintent);
                break;
        }

    }
}
