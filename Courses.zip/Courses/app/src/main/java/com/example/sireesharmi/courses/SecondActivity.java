package com.example.sireesharmi.courses;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Sireesharmi on 02-07-2016.
 */
public class SecondActivity extends Activity {

    TextView display;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_layout);
        display=(TextView)findViewById(R.id.display);

        Intent main=getIntent();
        String name=main.getStringExtra("Mentor");

        display.setText(name);
    }
}
